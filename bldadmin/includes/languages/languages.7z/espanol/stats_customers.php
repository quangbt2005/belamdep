<?php
/*
  $Id: stats_customers.php 1739 2007-12-20 00:52:16Z hpdl $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2003 osCommerce

  Released under the GNU General Public License
*/

define('HEADING_TITLE', 'Total de Pedidos por Cliente');

define('TABLE_HEADING_NUMBER', 'N&uacute;mero');
define('TABLE_HEADING_CUSTOMERS', 'Clientes');
define('TABLE_HEADING_TOTAL_PURCHASED', 'Total Pedido');
?>