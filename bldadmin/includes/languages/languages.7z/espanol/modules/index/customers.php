<?php
/*
  $Id: customers.php 1739 2007-12-20 00:52:16Z hpdl $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2007 osCommerce

  Released under the GNU General Public License
*/

define(ADMIN_INDEX_CUSTOMERS_TITLE, 'Customers');
define(ADMIN_INDEX_CUSTOMERS_DATE, 'Date');
?>
