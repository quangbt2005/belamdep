<?php
/*
  $Id: index.php 1739 2007-12-20 00:52:16Z hpdl $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2003 osCommerce

  Released under the GNU General Public License
*/

define('HEADING_TITLE', 'Seleccione una opci&oacute;n..');

define('BOX_TITLE_ORDERS', 'Pedidos');
define('BOX_TITLE_STATISTICS', 'Estadisticas');

define('BOX_ENTRY_SUPPORT_SITE', 'Soporte');
define('BOX_ENTRY_SUPPORT_FORUMS', 'Foros');
define('BOX_ENTRY_CONTRIBUTIONS', 'M&oacute;dulos');

define('BOX_ENTRY_CUSTOMERS', 'Clientes:');
define('BOX_ENTRY_PRODUCTS', 'Productos:');
define('BOX_ENTRY_REVIEWS', 'Comentarios:');

define('BOX_CONNECTION_PROTECTED', 'Esta protegido por una conexi&oacute;n SSL %s.');
define('BOX_CONNECTION_UNPROTECTED', '<font color="#ff0000">No</font> esta protegido por una conexi&oacute;n segura SSL.');
define('BOX_CONNECTION_UNKNOWN', 'desconocido');

define('CATALOG_CONTENTS', 'Contenido');

define('REPORTS_PRODUCTS', 'Productos');
define('REPORTS_ORDERS', 'Pedidos');

define('TOOLS_BACKUP', 'Copias');
define('TOOLS_BANNERS', 'Banners');
define('TOOLS_FILES', 'Ficheros');
?>
