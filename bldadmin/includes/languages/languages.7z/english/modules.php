<?php
/*
  $Id: modules.php 1802 2008-01-11 16:59:17Z hpdl $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2008 osCommerce

  Released under the GNU General Public License
*/

define('HEADING_TITLE_MODULES_PAYMENT', 'Payment Modules');
define('HEADING_TITLE_MODULES_SHIPPING', 'Shipping Modules');
define('HEADING_TITLE_MODULES_ORDER_TOTAL', 'Order Total Modules');

define('TABLE_HEADING_MODULES', 'Modules');
define('TABLE_HEADING_SORT_ORDER', 'Sort Order');
define('TABLE_HEADING_ACTION', 'Action');

define('TEXT_INFO_VERSION', 'Version:');
define('TEXT_INFO_ONLINE_STATUS', 'online status');

define('TEXT_MODULE_DIRECTORY', 'Module Directory:');
?>
