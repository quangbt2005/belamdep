<?php
/*
  $Id: stats_products_purchased.php 1739 2007-12-20 00:52:16Z hpdl $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('HEADING_TITLE', 'meist verkaufte Artikel');

define('TABLE_HEADING_NUMBER', 'Nr.');
define('TABLE_HEADING_PRODUCTS', 'Artikel');
define('TABLE_HEADING_PURCHASED', 'verkaufte Anzahl');
?>