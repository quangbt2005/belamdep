<?php
/*
  $Id: modules.php 1802 2008-01-11 16:59:17Z hpdl $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2008 osCommerce

  Released under the GNU General Public License
*/

define('HEADING_TITLE_MODULES_PAYMENT', 'Zahlungsweisen');
define('HEADING_TITLE_MODULES_SHIPPING', 'Versandarten');
define('HEADING_TITLE_MODULES_ORDER_TOTAL', 'Modul Zusammenfassung einer Bestellung');

define('TABLE_HEADING_MODULES', 'Module');
define('TABLE_HEADING_SORT_ORDER', 'Reihenfolge');
define('TABLE_HEADING_ACTION', 'Aktion');

define('TEXT_INFO_VERSION', 'Version:');
define('TEXT_INFO_ONLINE_STATUS', 'online status');

define('TEXT_MODULE_DIRECTORY', 'Modul Verzeichnis:');
?>